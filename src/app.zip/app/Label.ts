import { Element } from './Element';

export class Label extends Element {
  constructor() {
    super();
  }
}
