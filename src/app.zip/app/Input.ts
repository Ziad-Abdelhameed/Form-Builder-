import { Element } from './Element';

export class Input extends Element {
  constructor() {
    super();
  }
}
